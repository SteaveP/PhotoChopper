libconfig
=========

C/C++ library for processing configuration files
